//set variable to a random number [
//let cars =["bmw", "audi",255]   cars.push(benz) cars.pop()
//for (let i =0; i<10;i+1) json.stryngfy  to convert to string
let first =getRandomCard()
let second =getRandomCard()

let cards="cards: "+ first + " " +second 

let hasBlack =false
let isAlive = false

let sum = first + second

let name1 = "Stunna"
let chips = 680


let message = ""

function randergame()
{
if(sum<21){
    message = "Do you want to draw a new card"

}
else if(sum===21){
    message= "wowwww!! you got the black jack!"
    hasBlack = true
}
else{
    message ="youre out of the game! "
    isAlive =false
}
document.getElementById("message-el").textContent =message
document.getElementById("sum-el").textContent = "sum: "+ sum
document.getElementById("cards-el").textContent = cards
}

function startgame(){
    isAlive = true
    document.getElementById("player-el").textContent = name1 +" : $"+chips
    randergame()
}
function newcard(){ //draw new card
    if(isAlive ==true && hasBlack==false){
    let newc= getRandomCard()
     
    sum = sum + newc
    cards = cards + " "+newc
    randergame()
}
}


function getRandomCard(){  //functions are accessible on everywhere inside class
    let ran =  Math.floor(Math.random()*13)  //rndom generte no 0-0.999 . 
    if(ran>10)
    {
      return 10
    }
    if (ran ===1) {
        return 11
    } else {
        return ran
    }
} 

//objects 
//let player {
//   name: ricj , age:10   // to acces plaayer.name 
// syHi : function(){ xonsole.log("helo")} // wee can have functions under objects
//}
//array push pop shift unshift...push/pop - end of array  shift-remove/unshit(add) -begining of array