//document.getElementById("count-el").innerText=5
let count = 0  //variable count can also add subtract etc 
//count = count+1 //incriment
//console.log(count)  //print count
//create function
function increment(){
    count = count+1
    document.getElementById("count-el").innerText=count

}
function reset(){
    count =0
    document.getElementById("count-el").innerText =count
}
function decrement(){
    if (count>0)
       {count =count -1}
    document.getElementById("count-el").innerText=count
}

function save(){
    let outpu =" "+ count + " - "
document.getElementById("save-el").textContent += outpu

}